# Full code is already provided above; this is a placeholder
# Save this file as: generative_ai_comparison.py
# To run: python generative_ai_comparison.py