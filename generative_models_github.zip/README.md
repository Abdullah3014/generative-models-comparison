# Generative Models Comparison

This repository contains a unified simulation framework comparing the empirical performance of three major classes of generative models:

- Variational Autoencoders (VAEs)
- Generative Adversarial Networks (GANs)
- Denoising Diffusion Probabilistic Models (DDPMs)

## Files Included

- `generative_ai_comparison.py`: Python script to simulate and compare generative models.
- `vae_loss_curve.png`: Training loss curve for VAE.
- `vae_generated_vs_real.png`: VAE-generated samples vs real data.
- `gan_generated_vs_real.png`: GAN-generated samples vs real data.
- `training_time_comparison.png`: Bar chart comparing training time.
- `all_models_samples.png`: Overlay plot comparing VAE, GAN, and Diffusion outputs.

## Instructions

1. Upload the script and run in Google Colab or locally with Python 3.8+ and PyTorch.
2. All generated images are saved and ready for manuscript insertion.